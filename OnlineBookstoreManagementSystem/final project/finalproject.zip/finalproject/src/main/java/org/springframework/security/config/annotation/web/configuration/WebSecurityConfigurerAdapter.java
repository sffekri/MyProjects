package org.springframework.security.config.annotation.web.configuration;
import org.springframework.context.annotation.Configuration;

@Configuration
public class WebSecurityConfigurerAdapter {

}
